"""gsaEMS URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.urls.conf import include
from .views import VenueListView, VenueDetailView, VenueCreateView, VenueUpdateView, VenueDeleteView, MyVenueListView
from django.shortcuts import redirect, render, reverse
from django.http import HttpResponse

app_name = "venues"

urlpatterns = [
    path('', VenueListView.as_view(), name='venue-list'),
    path('<int:pk>/', VenueDetailView.as_view(), name = 'venue-detail'),
    path('<int:pk>/update/', VenueUpdateView.as_view(), name = 'venue-update'),
    path('<int:pk>/delete/', VenueDeleteView.as_view(), name='venue-delete'),
    path('create/', VenueCreateView.as_view(), name='venue-create'),


    path('myvenues/', MyVenueListView.as_view(), name = 'myvenue-list'),
    path('myvenues/<int:pk>/', VenueDetailView.as_view(), name = 'myvenue-detail'),
    path('myvenues/<int:pk>/update/', VenueUpdateView.as_view(), name = 'myvenue-update'),
    path('myvenues/<int:pk>/delete/', VenueDeleteView.as_view(), name='myvenue-delete'),
    
    
   
]
