/*const data = "{{qs_json}}"
fetch("test.json")
  .then(response => response.json())
  .then(json => console.log(json));
console.log(data)

const rdata = JSON.parse(data.replace(/&quot;/g, '"'))
    
const input = document.getElementById('search-user')
console.log(input)
let filteredArr = []*/

console.log('test')
const url = window.location.href
console.log(url)