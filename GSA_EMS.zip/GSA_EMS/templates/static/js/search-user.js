
const data = JSON.parse(document.getElementById('qs_json').textContent);
console.log(data)
const url = window.location.href
const searchForm = document.getElementById('search-user')
const searchInput = document.getElementById('search-user-input')
const resultsBox = document.getElementById('user-list')

const csrf = document.getElementsByName('csrfmiddlewaretoken')[0].value
console.log(url)

searchInput.addEventListener('keyup', e=>{
    console.log(e.target.value)
})